
static REAL8 model3a(const REAL8 nu, const REAL8 ai, const REAL8 lam, const REAL8 *par);
static void pijk_to_pk(REAL8 *p, const REAL8 nu, const REAL8 ai, const REAL8 *par);
static REAL8 model1a(const REAL8 x, const REAL8 *p);

