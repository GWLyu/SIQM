# Import SWIG wrappings, if available
from .lalsimulation import *

__version__ = "4.0.2"

## \addtogroup lalsimulation_python
"""This package provides Python wrappings and extensions to LALSimulation"""
