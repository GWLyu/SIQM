MathJax.Hub.Config({
    TeX: {
        // Enable automatic equation numbering
        equationNumbers: {
            autoNumber: "AMS"
        }
    }
});
