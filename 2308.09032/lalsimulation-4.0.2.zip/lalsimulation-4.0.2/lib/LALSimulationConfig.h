/* lib/LALSimulationConfig.h.  Generated from LALSimulationConfig.h.in by configure.  */
/* only include this file if LALSimulation's config.h has not been included */
#ifndef LALSIMULATION_VERSION

/* LALFrame Version */
#define LALSIMULATION_VERSION "4.0.2"

/* LALFrame Version Major Number  */
#define LALSIMULATION_VERSION_MAJOR 4

/* LALFrame Version Minor Number  */
#define LALSIMULATION_VERSION_MINOR 0

/* LALFrame Version Micro Number  */
#define LALSIMULATION_VERSION_MICRO 2

/* LALFrame Version Devel Number  */
#define LALSIMULATION_VERSION_DEVEL 0

#endif /* LALSIMULATION_VERSION */
