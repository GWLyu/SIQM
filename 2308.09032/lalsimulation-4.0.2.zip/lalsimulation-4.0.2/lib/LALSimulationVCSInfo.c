/*
 * Copyright (C) 2014, 2016 Karl Wette
 * Copyright (C) 2009-2013 Adam Mercer
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with with program; see the file COPYING. If not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301 USA
 */

/*
 * LALSimulationVCSInfo.c - LALSimulation VCS Information
 */

#include <stdlib.h>
#include <config.h>

#include <lal/LALVCSInfoType.h>

#if defined(HAVE_LIBLAL)
#include <lal/LALVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALFRAME)
#include <lal/LALFrameVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALMETAIO)
#include <lal/LALMetaIOVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALSIMULATION)
#include <lal/LALSimulationVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALBURST)
#include <lal/LALBurstVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALINSPIRAL)
#include <lal/LALInspiralVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALINFERENCE)
#include <lal/LALInferenceVCSInfoHeader.h>
#endif
#if defined(HAVE_LIBLALPULSAR)
#include <lal/LALPulsarVCSInfoHeader.h>
#endif

#include "LALSimulationVCSInfoHeader.h"
#include "LALSimulationBuildInfoHeader.h"

/* VCS and build information */
const LALVCSInfo lalSimulationVCSInfo = {
  .name = "LALSimulation",
  .version = LALSIMULATION_VERSION,
  .vcsId = LALSIMULATION_VCS_ID,
  .vcsDate = LALSIMULATION_VCS_DATE,
  .vcsBranch = LALSIMULATION_VCS_BRANCH,
  .vcsTag = LALSIMULATION_VCS_TAG,
  .vcsAuthor = LALSIMULATION_VCS_AUTHOR,
  .vcsCommitter = LALSIMULATION_VCS_COMMITTER,
  .vcsClean = LALSIMULATION_VCS_CLEAN,
  .vcsStatus = LALSIMULATION_VCS_STATUS,
  .configureArgs = LALSIMULATION_CONFIGURE_ARGS,
  .configureDate = LALSIMULATION_CONFIGURE_DATE,
  .buildDate = LALSIMULATION_BUILD_DATE,
};

/* Identable VCS and build information */
const LALVCSInfo lalSimulationVCSIdentInfo = {
  .name = "$LALSimulationName: " "LALSimulation" " $",
  .version = "$LALSimulationVersion: " LALSIMULATION_VERSION " $",
  .vcsId = "$LALSimulationVCSId: " LALSIMULATION_VCS_ID " $",
  .vcsDate = "$LALSimulationVCSDate: " LALSIMULATION_VCS_DATE " $",
  .vcsBranch = "$LALSimulationVCSBranch: " LALSIMULATION_VCS_BRANCH " $",
  .vcsTag = "$LALSimulationVCSTag: " LALSIMULATION_VCS_TAG " $",
  .vcsAuthor = "$LALSimulationVCSAuthor: " LALSIMULATION_VCS_AUTHOR " $",
  .vcsCommitter = "$LALSimulationVCSCommitter: " LALSIMULATION_VCS_COMMITTER " $",
  .vcsClean = "$LALSimulationVCSClean: " LALSIMULATION_VCS_CLEAN " $",
  .vcsStatus = "$LALSimulationVCSStatus: " LALSIMULATION_VCS_STATUS " $",
  .configureArgs = "$LALSimulationConfigureArgs: " LALSIMULATION_CONFIGURE_ARGS " $",
  .configureDate = "$LALSimulationConfigureDate: " LALSIMULATION_CONFIGURE_DATE " $",
  .buildDate = "$LALSimulationBuildDate: " LALSIMULATION_BUILD_DATE " $",
};

/* NULL-terminated list of library and dependencies VCS and build information */
const LALVCSInfoList lalSimulationVCSInfoList = {
#if defined(HAVE_LIBLAL)
  &lalVCSInfo,
#endif
#if defined(HAVE_LIBLALFRAME)
  &lalFrameVCSInfo,
#endif
#if defined(HAVE_LIBLALMETAIO)
  &lalMetaIOVCSInfo,
#endif
#if defined(HAVE_LIBLALSIMULATION)
  &lalSimulationVCSInfo,
#endif
#if defined(HAVE_LIBLALBURST)
  &lalBurstVCSInfo,
#endif
#if defined(HAVE_LIBLALINSPIRAL)
  &lalInspiralVCSInfo,
#endif
#if defined(HAVE_LIBLALINFERENCE)
  &lalInferenceVCSInfo,
#endif
#if defined(HAVE_LIBLALPULSAR)
  &lalPulsarVCSInfo,
#endif
  &lalSimulationVCSInfo,
  NULL
};

#if LALSIMULATION_VERSION_DEVEL != 0
/*
 * VCS header/library mismatch link check function:
 * This function will successfully link only if the link check functions defined
 * in the included LAL VCS info headers (e.g. LAL_VCS_LINK_CHECK() defined in
 * <lal/LALVCSInfoHeader.h>) are present in the LAL libraries being linked
 * against. A successful link ensures that the LAL headers included by this
 * library are consistent with the LAL libraries linked against by this library.
 */
void LALSIMULATION_VCS_LINK_CHECK(void)
{
#if defined(HAVE_LIBLAL) && LAL_VERSION_DEVEL != 0
  LAL_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALFRAME) && LALFRAME_VERSION_DEVEL != 0
  LALFRAME_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALMETAIO) && LALMETAIO_VERSION_DEVEL != 0
  LALMETAIO_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALSIMULATION) && LALSIMULATION_VERSION_DEVEL != 0
  LALSIMULATION_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALBURST) && LALBURST_VERSION_DEVEL != 0
  LALBURST_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALINSPIRAL) && LALINSPIRAL_VERSION_DEVEL != 0
  LALINSPIRAL_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALINFERENCE) && LALINFERENCE_VERSION_DEVEL != 0
  LALINFERENCE_VCS_LINK_CHECK();
#endif
#if defined(HAVE_LIBLALPULSAR) && LALPULSAR_VERSION_DEVEL != 0
  LALPULSAR_VCS_LINK_CHECK();
#endif
}
#endif
