static REAL8 TanhWindow(const REAL8 f, const int sign, const REAL8 f0, const REAL8 sigma);
static REAL8 CalcRDFrequency(REAL8 MF, REAL8 chiF, REAL8 Mtot);

